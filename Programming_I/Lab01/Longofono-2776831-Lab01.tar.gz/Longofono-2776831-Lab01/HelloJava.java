public class HelloJava{
	
	public static void main(String[] args){
		System.out.println("Hello Java!");
		System.out.print("Didn't start a new line this time");
		System.out.println("This is going to be a fun lab!!");
	}
}
