
public class MySecond {
public static void main (String[] args){
	System.out.println("Hello again java!"+"  I am experimenting with syntax!");
	System.out.println("I hope I'm doing this correctly, else i may lose points on my first day!");
	System.out.println("This is my second java program!  I am clearly excited about it, as you might guess from my exclamation points!!!");
}
}
