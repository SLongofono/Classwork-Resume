/*
 * CircleArea.java
 * Stephen Longofono s580l129@ku.edu
 * EECS_168 Lab02
 * 9/8/2014
 */
public class CircleArea {
//main block
	public static void main(String[] args){
	//code block
	//declare variables, constants
	final double PI = 3.14592;
	double radius = 20.0;
	System.out.println("The area for the circle with given radius " + radius + " units is " + radius*radius*PI + " square units.");
}
}